normal_return:: [Int] -> [Int]
normal_return [] = []
normal_return (x:xs) = 
    x : double_odd xs
    
double_odd:: [Int] -> [Int]
double_odd [] = []
double_odd (x:xs) = 
    x * 2 : normal_return xs

filter_number_greather_10:: Int -> Int 
filter_number_greather_10 number = 
    if number >= 10 then 
        ((div number 10) + (mod number 10))
    else number

luhn:: [Int] -> Bool
luhn list = 
    (mod (foldr (+) 0 (map filter_number_greather_10 (double_odd [9,3,4,2,1,6,4,3,0]))) 10) == 0
main = print (luhn [9,3,4,2,1,6,4,3,0])