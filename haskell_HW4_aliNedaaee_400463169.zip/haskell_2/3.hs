sum_func :: Maybe Int -> Maybe Int -> Maybe Int
--sum_func Nothing Nothing = Nothing
sum_func num1 Nothing = Nothing
sum_func Nothing num2   = Nothing
sum_func (Just num1) (Just num2) = Just ( num1 + num2 )

--main = print(sum_func (Just 10) (Just 12))

--main = print(sum_func Nothing (Just 12))

main = print(sum_func Nothing Nothing)