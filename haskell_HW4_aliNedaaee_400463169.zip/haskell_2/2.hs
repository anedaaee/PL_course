function :: Int -> Bool
function number = 
    if number == 0 
        then False
        else True

filterF :: Foldable t => (a -> Bool) -> t a -> [a]
filterF f = foldr (\x acc -> if f x then x : acc else acc) []


main = print(filterF function [1, 2, 0, 3, 4, 5, 6, 0, 7, 8, 9, 10])