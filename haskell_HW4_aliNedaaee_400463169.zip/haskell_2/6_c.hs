data Tree a =
    Leaf | 
    Node a (Tree a) (Tree a)
    deriving Show

tree :: Tree Int
tree = Node 1
                (Node 4 Leaf Leaf)
                (Node 3
                    (Node 4 Leaf Leaf)
                    (Node 5 Leaf Leaf))


rigth_subtree_count :: Tree a -> Int
rigth_subtree_count Leaf = 0  
rigth_subtree_count (Node _ left right) = 
    1 + rigth_subtree_count right

main = print(rigth_subtree_count tree)