fac :: Maybe Int -> Maybe Int
fac Nothing = Nothing
fac (Just number) = Just(foldr (*) 1 [1..number])

main = print(fac (Just 5))